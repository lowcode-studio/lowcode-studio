window.constants = {
	...JSON.parse(window.sessionStorage.getItem('constants')),
    appCode: appCode,
	theme: {
        primaryColor: '#fe7300',
        successColor: '#52c41a',
        warningColor: '#faad14',
        errorColor: '#f5222d',
    },
}